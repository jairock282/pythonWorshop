##Ejercicio 1

def max_in_list(*args):

	lista = list(args)

	numElementos = len(lista)

	print(max(lista))

max_in_list(1, 2, 3, 4)

