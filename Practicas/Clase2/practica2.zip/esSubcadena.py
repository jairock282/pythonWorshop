#Pedimos las cadenas de caracteres
cont = 0
#igual = false

print("Ingrese su primera cadena: ")
primera = input()

print("Ingrese su segunda cadena: ")
segunda = input()

if primera.find(segunda) >= 0:

	print("La segunda cadena es subCadena de la primera!")
else:

	print("La seguda cadena no es subCadena de la primera!")

#print(primera.find(segunda))


