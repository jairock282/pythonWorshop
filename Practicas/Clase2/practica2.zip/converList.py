#Definimos nustras listas
sub1 = [3, 4]
sub2 = [2, sub1]
listaPapa = [1, sub2, 5]

#print(sub1)
#print(sub2)
print(listaPapa)

sub3 = [2, sub1, [6, 7]]
listaMama = [1, sub3, 5]
print(listaMama)
