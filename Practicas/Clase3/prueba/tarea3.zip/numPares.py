##Numero pares del 0 al 100

#Realizamos un ciclo que va desde el 2(primer numero par) con saltos de dos en dos
for i in range(2, 100, 2):

	print(i)

